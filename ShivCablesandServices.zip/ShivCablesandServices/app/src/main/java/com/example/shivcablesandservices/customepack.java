package com.example.shivcablesandservices;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class customepack extends AppCompatActivity {

    private CardView cvZee, cvStar, cvColor, cvNews, cvCartoon;
    private TextView tvPrice;
    public static  String price;
    public static  String zee , star , color , news , cartoon;
    public static int p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customepack);

        cvZee = findViewById(R.id.cvZee);
        cvStar = findViewById(R.id.cvStar);
        cvColor = findViewById(R.id.cvColor);
        cvNews = findViewById(R.id.cvNews);
        cvCartoon = findViewById(R.id.cvCartoon);

        tvPrice = findViewById(R.id.tvPrice);

        p = 0;
        zee ="";
        star ="";
        color="";
        news="";
        cartoon="";

        recharge.plan = "Custom Pack" ;


        price = "0";
    }

    private void setPrice(String price) {
        p += Integer.parseInt(price);
        Splash_Screen.price = Integer.toString(p) ;

    }

    public void zee(View view) {
        price = "180";
        zee="Zee";
        cvZee.setCardBackgroundColor(Color.GREEN);

        setPrice(price);

    }

    public void star(View view) {
        price = "230";
        star="Star";
        cvStar.setCardBackgroundColor(Color.GREEN);
        setPrice(price);

    }


    public void color(View view) {
        price = "200";
        color="Color";
        cvColor.setCardBackgroundColor(Color.GREEN);
        setPrice(price);


    }

    public void news(View view) {
        price = "170";
        news="News";
        cvNews.setCardBackgroundColor(Color.GREEN);
        setPrice(price);

    }

    public void cartoon(View view) {

        price = "250";
        cartoon ="Cartoon";
        cvCartoon.setCardBackgroundColor(Color.GREEN);
        setPrice(price);

    }


    public void recharge(View view) {
        if (price == "0") {
            Toast.makeText(this, "Please Select Plan..!!", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(customepack.this , DisplayRecharge.class);
            intent.putExtra("Price" , Integer.toString(p));
            startActivity(intent);
        }

    }
}