package com.example.shivcablesandservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class net_plan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_net_plan);
    }

    public void regiaterUpcoming(View view) {
        Intent rgs= new Intent(net_plan.this,internet_register.class);
        startActivity(rgs);

    }
}