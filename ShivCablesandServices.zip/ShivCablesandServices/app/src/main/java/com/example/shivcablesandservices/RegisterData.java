package com.example.shivcablesandservices;

public class RegisterData {
    String rrd_email;
    String rrd_card;
    String rrd_pass;
    String rrd_mobile;
    String rrd_Username;
    String rrd_plan;

    public RegisterData(String rrd_email, String rrd_card, String rrd_pass, String rrd_mobile, String rrd_Username,String rrd_plan) {
        this.rrd_email = rrd_email;
        this.rrd_card = rrd_card;
        this.rrd_pass = rrd_pass;
        this.rrd_mobile = rrd_mobile;
        this.rrd_Username = rrd_Username;
        this.rrd_plan =rrd_plan;

    }

    public RegisterData() {

    }

    public String getRrd_email() {
        return rrd_email;
    }

    public String getRrd_card() {
        return rrd_card;
    }

    public String getRrd_pass() {
        return rrd_pass;
    }

    public String getRrd_mobile() {
        return rrd_mobile;
    }

    public String getRrd_Username() {
        return rrd_Username;
    }

    public String plan() {
        return rrd_plan;
    }


}
