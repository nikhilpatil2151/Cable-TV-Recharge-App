package com.example.shivcablesandservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class DisplayRecharge extends AppCompatActivity {

    TextView tvRecharge ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_recharge);

        tvRecharge = findViewById(R.id.tvRecharge);

        Intent intent = getIntent();
        String price = intent.getStringExtra("Price");

        tvRecharge.setText("Recharge : " + Splash_Screen.price);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(DisplayRecharge.this , Home_page.class));
            }
        }, 2000) ;
    }
}