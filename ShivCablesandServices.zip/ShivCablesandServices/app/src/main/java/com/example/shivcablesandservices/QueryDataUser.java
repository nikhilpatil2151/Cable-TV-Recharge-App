package com.example.shivcablesandservices;

public class QueryDataUser {

    String ggQuery;

    public  QueryDataUser(){

    }

    public QueryDataUser(String ggQuery) {
        this.ggQuery = ggQuery;
    }

    public String getGgQuery() {

        return ggQuery;
    }
}
