package com.example.shivcablesandservices;

import static com.example.shivcablesandservices.recharge.plan;
import static com.example.shivcablesandservices.recharge.price;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class about extends AppCompatActivity {
    TextView t1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        t1=findViewById(R.id.dis1);

        t1.setText("Recharge : "+ Splash_Screen.price
                +"\nPlan : " + plan);




    }
}