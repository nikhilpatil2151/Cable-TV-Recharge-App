package com.example.shivcablesandservices;

public class UserInternetData {

    String nameID;
    String addressID;
    String mobilenoID;
    String plannameID;

    public UserInternetData(String nameID, String addressID, String mobilenoID, String plannameID) {
        this.nameID = nameID;
        this.addressID = addressID;
        this.mobilenoID = mobilenoID;
        this.plannameID = plannameID;
    }

    public UserInternetData(){

    }

    public String getNameID() {
        return nameID;
    }

    public String getAddressID() {
        return addressID;
    }

    public String getMobilenoID() {
        return mobilenoID;
    }

    public String getPlannameID() {
        return plannameID;
    }
}
