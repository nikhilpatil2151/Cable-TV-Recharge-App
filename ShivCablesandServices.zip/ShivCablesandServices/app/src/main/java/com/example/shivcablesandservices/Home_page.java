package com.example.shivcablesandservices;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Home_page extends AppCompatActivity {

    ImageView logoutBtn;
    String mhomeusername;
    CardView recharge ;


    TextView display_username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        display_username = findViewById(R.id.display_username);
        logoutBtn=findViewById(R.id.btnout);
        recharge = findViewById(R.id.cableRecharge) ;

        if (Splash_Screen.price != ""){
         recharge.setEnabled(false);
        }

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it4 = new Intent(Home_page.this,Login_page.class);
                startActivity(it4);
            }
        });


        String A = MainActivity.musername;
        mhomeusername = Login_page.musername;


        FirebaseDatabase.getInstance().getReference().child("RegisterData").addValueEventListener(new ValueEventListener() {
            String nikhil_display_name;
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot keyId: snapshot.getChildren())
                {
                    if(keyId.child("rrd_email").getValue().equals(A))
                    {
                        nikhil_display_name = keyId.child("rrd_Username").getValue(String.class);
                        break;
                    }
                }

                display_username.setText(mhomeusername);

            }




            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }




    public void cableRechargess(View view) {
        Intent cr=new Intent(Home_page.this,recharge.class);
        startActivity(cr);

    }

    public void internetPlans(View view) {
        Intent ip=new Intent(Home_page.this,net_plan.class);
        startActivity(ip);

    }

    public void query(View view) {
        Intent qu=new Intent(Home_page.this,query.class);
        startActivity(qu);

    }

    public void about(View view) {
        Intent ab=new Intent(Home_page.this,about.class);
        startActivity(ab);

    }
}