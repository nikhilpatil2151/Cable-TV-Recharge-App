package com.example.shivcablesandservices;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login_page extends AppCompatActivity {

    EditText loginemail,loginpass;
    Button loginbtn;
    ProgressBar loginprogressBar;
    TextView create_account_btn;
    public static String musername ;

    FirebaseAuth fAuth;

    public static String Aemail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        loginemail = findViewById(R.id.loginemail);
        loginpass = findViewById(R.id.loginpass);
        loginbtn = findViewById(R.id.loginbtn);
        loginprogressBar = findViewById(R.id.loginprogressBar);
        create_account_btn = findViewById(R.id.create_account_btn);

        fAuth = FirebaseAuth.getInstance();




        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String email = loginemail.getText().toString().trim();
                String password = loginpass.getText().toString().trim();
                musername = loginemail.getText().toString();


                if(TextUtils.isEmpty(email))
                {
                    loginemail.setError("Email is required");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    loginpass.setError("Password is empty");
                    return;
                }

                loginprogressBar.setVisibility(View.VISIBLE);


                // authenticate user from register page


                fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {


                        if(task.isSuccessful())
                        {
                            Toast.makeText(Login_page.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),Home_page.class));
                        }
                        else
                        {
                            Toast.makeText(Login_page.this, "Error ! "+ task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            loginprogressBar.setVisibility(View.GONE);

                        }


                    }
                });


            }
        });


        create_account_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Login_page.this,MainActivity.class);
                startActivity(intent);

            }
        });



    }
}