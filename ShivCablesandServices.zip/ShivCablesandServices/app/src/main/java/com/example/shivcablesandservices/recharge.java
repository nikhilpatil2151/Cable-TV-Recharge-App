package com.example.shivcablesandservices;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class recharge extends AppCompatActivity {

    private CardView cvPlatinum , cvGold , cvSilver , cvBasic , cvCustomPack ;
    public static String price , plan;
    private TextView tvPrice , tvDisplay;
    int p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recharge);

        cvPlatinum = findViewById(R.id.cvPlatinum);
        cvGold = findViewById(R.id.cvGold);
        cvSilver = findViewById(R.id.cvSilver);
        cvBasic = findViewById(R.id.cvBasic);
        cvCustomPack = findViewById(R.id.cvCustomPack);

        tvPrice = findViewById(R.id.tvPrice);
        tvDisplay = findViewById(R.id.dis1) ;

        p=0;
        plan = "" ;
         price = "0" ;

    }


    public void Platinum(View view) {
        Splash_Screen.price = "350" ;
        plan = "Platinum" ;
        cvPlatinum.setCardBackgroundColor(Color.GREEN);
        cvGold.setCardBackgroundColor(Color.WHITE);
        cvSilver.setCardBackgroundColor(Color.WHITE);
        cvBasic.setCardBackgroundColor(Color.WHITE);
        cvCustomPack.setCardBackgroundColor(Color.WHITE);
        setPrice(price);

    }

    private void setPrice(String price) {
        tvPrice.setVisibility(View.INVISIBLE);
        tvPrice.setText("Total Price : " + price);

    }

    public void Gold(View view) {
        Splash_Screen.price = "300";
        plan="Gold";
        cvGold.setCardBackgroundColor(Color.GREEN);
        cvPlatinum.setCardBackgroundColor(Color.WHITE);
        cvSilver.setCardBackgroundColor(Color.WHITE);
        cvBasic.setCardBackgroundColor(Color.WHITE);
        cvCustomPack.setCardBackgroundColor(Color.WHITE);
        setPrice(price);


    }

    public void Sliver(View view) {
        Splash_Screen.price = "250";
        plan="Sliver";
        cvSilver.setCardBackgroundColor(Color.GREEN);
        cvPlatinum.setCardBackgroundColor(Color.WHITE);
        cvGold.setCardBackgroundColor(Color.WHITE);
        cvBasic.setCardBackgroundColor(Color.WHITE);
        cvCustomPack.setCardBackgroundColor(Color.WHITE);
        setPrice(price);

    }

    public void Basic(View view) {
        Splash_Screen.price = "200";
        plan="Basic";
        cvBasic.setCardBackgroundColor(Color.GREEN);
        cvPlatinum.setCardBackgroundColor(Color.WHITE);
        cvGold.setCardBackgroundColor(Color.WHITE);
        cvSilver.setCardBackgroundColor(Color.WHITE);
        cvCustomPack.setCardBackgroundColor(Color.WHITE);
        setPrice(price);

    }

    public void CustomePack(View view) {
        cvCustomPack.setCardBackgroundColor(Color.GREEN);
        cvPlatinum.setCardBackgroundColor(Color.WHITE);
        cvGold.setCardBackgroundColor(Color.WHITE);
        cvSilver.setCardBackgroundColor(Color.WHITE);
        cvBasic.setCardBackgroundColor(Color.WHITE);
        setPrice(price);

        Intent it = new Intent(recharge.this,customepack.class);
        startActivity(it);
    }

    public void rechargebtn(View view) {
        if (Splash_Screen.price=="0"){
            Toast.makeText(this, "Please Select Plan..!!", Toast.LENGTH_SHORT).show();
        }
        else {
            Intent intent = new Intent(recharge.this,DisplayRecharge.class);
            intent.putExtra("Price" , price);
            startActivity(intent);
            Toast.makeText(this, "Recharge Successful...!", Toast.LENGTH_SHORT).show();
        }

    }
}