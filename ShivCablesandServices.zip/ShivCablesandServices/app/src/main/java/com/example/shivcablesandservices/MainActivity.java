package com.example.shivcablesandservices;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    EditText regemail,regcard,regpass,regmobile,regeUsername;
    Button regbtn;
    TextView already_account_btn;
    FirebaseAuth fAuth;
    DatabaseReference register;
    AwesomeValidation awesomeValidation;

    public static String musername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("tag" , "main");

        regemail = findViewById(R.id.regemail);
        regcard = findViewById(R.id.regcard);
        regpass = findViewById(R.id.regpass);
        regmobile = findViewById(R.id.regmobile);
        regbtn = findViewById(R.id.regbtn);
        regeUsername =findViewById(R.id.regeUsername);

        awesomeValidation=new AwesomeValidation(ValidationStyle.BASIC);

        awesomeValidation.addValidation(this,R.id.regemail, RegexTemplate.NOT_EMPTY,R.string.invalid_name);
        awesomeValidation.addValidation(this,R.id.regcard, RegexTemplate.NOT_EMPTY,R.string.invalid_name);
        awesomeValidation.addValidation(this,R.id.regpass, RegexTemplate.NOT_EMPTY,R.string.invalid_name);
        awesomeValidation.addValidation(this,R.id.regmobile, RegexTemplate.NOT_EMPTY,R.string.invalid_name);
        awesomeValidation.addValidation(this,R.id.regeUsername, RegexTemplate.NOT_EMPTY,R.string.invalid_name);





        already_account_btn = findViewById(R.id.already_account_btn);

        fAuth = FirebaseAuth.getInstance();
        register= FirebaseDatabase.getInstance().getReference().child("RegisterData");




        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = regemail.getText().toString().trim();
                String password = regpass.getText().toString().trim();

                if (awesomeValidation.validate())
                {

                    fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {


                            musername = regeUsername.getText().toString();
                            if(task.isSuccessful())
                            {
                                registerDataUserclass();
                                Toast.makeText(MainActivity.this, "User created", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(),Login_page.class));
                            }
                            else
                            {
                                Toast.makeText(MainActivity.this, "Error ! "+ task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                            }

                        }
                    });

                }

            }
        });

        already_account_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Login_page.class);
                startActivity(intent);
            }

        });

    }
    private void registerDataUserclass() {
        String rdEmail=regemail.getText().toString();
        String rdCard=regcard.getText().toString();
        String rdPass=regpass.getText().toString();
        String rdMobileNo=regmobile.getText().toString();
        String rdUsername = regeUsername.getText().toString();
        String rdplan="0";

        RegisterData rgisterdatauser= new RegisterData(rdEmail,rdCard,rdPass,rdMobileNo,rdUsername,rdplan);

        register.push().setValue(rgisterdatauser );


    }
}