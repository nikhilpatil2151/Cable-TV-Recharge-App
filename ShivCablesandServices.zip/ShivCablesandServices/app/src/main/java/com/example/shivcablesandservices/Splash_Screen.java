package com.example.shivcablesandservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

public class Splash_Screen extends AppCompatActivity {

    public static String price ;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        price = "";


        Thread thread = new Thread()
        {
            public void run()
            {
                try {

                    sleep(2000);

                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                finally {

                    Intent intent = new Intent(Splash_Screen.this,Login_page.class);
                    startActivity(intent);

                }
            }
        };thread.start();

    }
}