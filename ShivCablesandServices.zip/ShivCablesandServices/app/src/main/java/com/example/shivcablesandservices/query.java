package com.example.shivcablesandservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class query extends AppCompatActivity {
    EditText etquery;
    Button b1;
    DatabaseReference queryData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);
        etquery=findViewById(R.id.etquery);
        b1=findViewById(R.id.btn);
        queryData=FirebaseDatabase.getInstance().getReference().child("QueryDataUser");



    }


    public void etbtn(View view) {

        if (etquery.getText().toString().trim().isEmpty()){
            Toast.makeText(query.this,"Please type Query",Toast.LENGTH_SHORT).show();
        }
        else {
            getQueryData();
            Toast.makeText(query.this,"Successfuly submited Query",Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(query.this , Home_page.class));
                }
            }, 2000) ;


        }

    }

    private void getQueryData() {
        String gquery=etquery.getText().toString();

        QueryDataUser qdu= new QueryDataUser(gquery);
        queryData.push().setValue(qdu);
    }

}