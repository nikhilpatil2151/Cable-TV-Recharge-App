package com.example.shivcablesandservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class internet_register extends AppCompatActivity {
    EditText FullName,Address,MobileNo,PlanName;
    TextView succssful;
    DatabaseReference internetRegDbRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internet_register);
        FullName=findViewById(R.id.FullName);
        Address=findViewById(R.id.Address);
        MobileNo=findViewById(R.id.MobileNo);
        PlanName=findViewById(R.id.PlanName);

        succssful=findViewById(R.id.succssful);

        internetRegDbRef = FirebaseDatabase.getInstance().getReference().child("UserInternetData");

    }
    private void setPrice() {
        succssful.setVisibility(View.INVISIBLE);
        succssful.setText("Successfully submited response ");

    }

    public void submit(View view) {


        if (FullName.getText().toString().isEmpty()){
            if(FullName.getText().equals("")){
                FullName.setError("Full Name is complusory");

            }

        }
        else {
            insertUserData();
            setPrice();
            succssful.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(internet_register.this , Home_page.class));
                }
            }, 2000) ;
        }

    }

    private void insertUserData() {
        String fullname=FullName.getText().toString();
        String address=Address.getText().toString();
        String mobileno=MobileNo.getText().toString();
        String planname=PlanName.getText().toString();

        UserInternetData uid=new UserInternetData(fullname,address,mobileno,planname);

        internetRegDbRef.push().setValue(uid);

    }


}